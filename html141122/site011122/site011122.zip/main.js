

const piano = document.getElementById("pianobox");

for(let x = 0; x < 52; x++){
    
    const pianoKey = document.createElement("div");
    pianoKey.className = "keyWhite";
    pianoKey.setAttribute("id", String.fromCharCode((2+x)%7 + 97) + Math.floor(x/7)); //sets id to piano keytone. e.g. c,d,e,f,g,a,b,c ect
    pianoKey.style.gridColumn = `${x} / span 1`;
    pianoKey.style.gridRow = "0 / span 2" ;
    pianoKey.style.border = "2px solid black";
    piano.appendChild(pianoKey);
}
